package com.kcl.tokenlogin.client.ui;

import com.kcl.tokenlogin.TokenLogin;
import com.kcl.tokenlogin.client.config.TokenLoginConfig;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Supplier;

/**
 * General settings; also opened from Mod Menu when it is installed.
 *
 * <p>The block is taller than a small window, so it scrolls: every row lives in
 * content coordinates and is shifted by {@link #scroll} when it is drawn, and
 * the real buttons are moved to the same place so clicks stay aligned.</p>
 *
 * <p>Colours are written with an explicit {@code 0xFF} alpha because the 1.21.11
 * {@code DrawContext} silently skips any text whose colour is fully transparent.</p>
 */
public final class SettingsScreen extends Screen {
    private static final int COLOR_LABEL = 0xFFFFFFFF;
    private static final int COLOR_HINT = 0xFFA0A0A0;
    private static final int COLOR_SECTION = 0xFFFFFF55;

    /** Left and right padding of the whole block. */
    private static final int MARGIN = 40;
    private static final int ROW_WIDTH = 180;
    private static final int LINE_HEIGHT = 9;
    /** Distance from the label baseline to the top of its button. */
    private static final int LABEL_TO_BUTTON = 11;
    private static final int BUTTON_HEIGHT = 20;
    private static final int NOTE_GAP = 5;
    private static final int ITEM_GAP = 9;
    private static final int SECTION_HEIGHT = 21;

    private final Screen parent;
    private final List<Row> rows = new ArrayList<>();
    private ButtonWidget positionButton;
    private ButtonWidget autoRefreshButton;
    private ButtonWidget favoritesButton;
    private ButtonWidget reorderButton;
    private ButtonWidget accountsButton;
    private double scroll;
    /** Visible strip of the scrolling block, in screen coordinates. */
    private int viewTop;
    private int viewBottom;
    private int contentHeight;

    public SettingsScreen(Screen parent) {
        super(Text.translatable("tokenlogin.settings.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        this.viewTop = 34;
        this.viewBottom = this.height - 66;

        this.positionButton = ButtonWidget.builder(positionMessage(), pressed -> {
                TokenLoginConfig.cycleButtonPosition();
                pressed.setMessage(positionMessage());
            })
            .dimensions(0, 0, buttonWidth(), BUTTON_HEIGHT)
            .build();
        this.autoRefreshButton = toggle(SettingsScreen::autoRefreshMessage,
            () -> TokenLoginConfig.toggleAutoRefresh());
        this.favoritesButton = toggle(SettingsScreen::favoritesMessage,
            () -> TokenLoginConfig.toggleFavorites());
        this.reorderButton = toggle(SettingsScreen::reorderMessage,
            () -> TokenLoginConfig.toggleReorder());
        this.accountsButton = ButtonWidget.builder(Text.translatable("tokenlogin.settings.open_accounts"),
                pressed -> this.client.setScreen(new AccountManagerScreen(this)))
            .dimensions(0, 0, buttonWidth(), BUTTON_HEIGHT)
            .build();

        this.addDrawableChild(this.positionButton);
        this.addDrawableChild(this.autoRefreshButton);
        this.addDrawableChild(this.favoritesButton);
        this.addDrawableChild(this.reorderButton);
        this.addDrawableChild(this.accountsButton);
        this.addDrawableChild(ButtonWidget.builder(Text.translatable("tokenlogin.settings.done"),
                pressed -> this.close())
            .dimensions(this.width / 2 - 60, this.height - 36, 120, 20)
            .build());

        buildRows();
        layoutRows();
        applyScroll();
    }

    /** The settings in the order they are shown: what the mod draws, then the list, then the screen itself. */
    private void buildRows() {
        this.rows.clear();
        this.rows.add(Row.header(Text.translatable("tokenlogin.settings.general")));
        this.rows.add(Row.control(Text.translatable("tokenlogin.settings.position"),
            Text.translatable("tokenlogin.settings.position.note"), this.positionButton));
        this.rows.add(Row.control(Text.translatable("tokenlogin.settings.auto_refresh"),
            Text.translatable("tokenlogin.settings.auto_refresh.note"), this.autoRefreshButton));

        this.rows.add(Row.header(Text.translatable("tokenlogin.settings.account_list")));
        this.rows.add(Row.control(Text.translatable("tokenlogin.settings.favorites"),
            Text.translatable("tokenlogin.settings.favorites.note"), this.favoritesButton));
        this.rows.add(Row.control(Text.translatable("tokenlogin.settings.reorder"),
            Text.translatable("tokenlogin.settings.reorder.note"), this.reorderButton));

        this.rows.add(Row.header(Text.translatable("tokenlogin.settings.accounts")));
        this.rows.add(Row.control(null, null, this.accountsButton));
    }

    /** Stacks every row from the top of the content and remembers the total height. */
    private void layoutRows() {
        int y = 0;
        int noteWidth = noteWidth();
        for (Row row : this.rows) {
            row.y = y;
            if (row.header) {
                row.height = SECTION_HEIGHT;
            } else {
                row.noteOffset = LABEL_TO_BUTTON + BUTTON_HEIGHT + NOTE_GAP;
                int lines = row.note == null ? 0 : this.textRenderer.wrapLines(row.note, noteWidth).size();
                row.height = row.noteOffset + lines * LINE_HEIGHT + ITEM_GAP;
            }
            y += row.height;
        }
        this.contentHeight = Math.max(0, y - ITEM_GAP);
    }

    /** Clamps the scroll and moves the visible buttons onto the scrolled rows. */
    private void applyScroll() {
        int viewHeight = Math.max(1, this.viewBottom - this.viewTop);
        double max = Math.max(0d, this.contentHeight - viewHeight);
        this.scroll = Math.max(0d, Math.min(this.scroll, max));
        int offset = this.viewTop - (int) Math.round(this.scroll);
        for (Row row : this.rows) {
            if (row.button == null) {
                continue;
            }
            int buttonY = offset + row.y + LABEL_TO_BUTTON;
            row.button.setX(margin());
            row.button.setY(buttonY);
            // A half hidden button must not stay clickable outside the strip.
            row.button.visible = buttonY + BUTTON_HEIGHT > this.viewTop && buttonY < this.viewBottom;
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 16, COLOR_LABEL);

        int offset = this.viewTop - (int) Math.round(this.scroll);
        context.enableScissor(margin(), this.viewTop, this.width - margin(), this.viewBottom);
        for (Row row : this.rows) {
            int y = offset + row.y;
            if (y + row.height < this.viewTop || y > this.viewBottom) {
                continue;
            }
            if (row.header) {
                context.drawTextWithShadow(this.textRenderer, row.label, margin(), y + 4, COLOR_SECTION);
                context.fill(margin(), y + SECTION_HEIGHT - 7, this.width - margin(),
                    y + SECTION_HEIGHT - 6, 0x80FFFFFF);
                continue;
            }
            if (row.label != null) {
                context.drawTextWithShadow(this.textRenderer, row.label, margin(), y, COLOR_LABEL);
            }
            if (row.note != null) {
                context.drawWrappedTextWithShadow(this.textRenderer, row.note, margin(),
                    y + row.noteOffset, noteWidth(), COLOR_HINT);
            }
        }
        context.disableScissor();

        renderScrollbar(context);
        context.drawWrappedTextWithShadow(this.textRenderer,
            Text.translatable("tokenlogin.settings.hotkey_hint"), margin(), this.height - 60,
            noteWidth(), COLOR_HINT);
        context.drawTextWithShadow(this.textRenderer,
            Text.literal(TokenLogin.MOD_NAME + " " + version() + " · " + TokenLogin.AUTHOR),
            20, this.height - 18, 0xFF808080);
        super.render(context, mouseX, mouseY, delta);
    }

    private void renderScrollbar(DrawContext context) {
        int viewHeight = this.viewBottom - this.viewTop;
        if (viewHeight <= 0 || this.contentHeight <= viewHeight) {
            return;
        }
        int x = this.width - margin() + 6;
        context.fill(x, this.viewTop, x + 3, this.viewBottom, 0x44FFFFFF);
        int barHeight = Math.max(18, viewHeight * viewHeight / this.contentHeight);
        double max = this.contentHeight - viewHeight;
        int barY = this.viewTop + (int) ((viewHeight - barHeight) * (max <= 0d ? 0d : this.scroll / max));
        context.fill(x, barY, x + 3, barY + barHeight, 0xAAFFFFFF);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount)) {
            return true;
        }
        if (mouseX >= margin() && mouseX < this.width - margin()
            && mouseY >= this.viewTop && mouseY < this.viewBottom) {
            this.scroll -= verticalAmount * 24d;
            applyScroll();
            return true;
        }
        return false;
    }

    /** Horizontal padding, narrowed on very small windows so the buttons still fit. */
    private int margin() {
        return Math.max(8, Math.min(MARGIN, (this.width - ROW_WIDTH) / 2));
    }

    private int buttonWidth() {
        return Math.min(ROW_WIDTH, this.width - margin() * 2);
    }

    private int noteWidth() {
        return Math.max(60, this.width - margin() * 2 - 8);
    }

    private ButtonWidget toggle(Supplier<Text> message, BooleanSupplier action) {
        return ButtonWidget.builder(message.get(), pressed -> {
                action.getAsBoolean();
                pressed.setMessage(message.get());
            })
            .dimensions(0, 0, buttonWidth(), BUTTON_HEIGHT)
            .build();
    }

    private static Text positionMessage() {
        return Text.translatable("tokenlogin.settings.position_value",
            Text.translatable(TokenLoginConfig.getButtonPosition().translationKey()));
    }

    private static Text autoRefreshMessage() {
        return Text.translatable("tokenlogin.settings.auto_refresh_value", onOff(TokenLoginConfig.isAutoRefresh()));
    }

    private static Text favoritesMessage() {
        return Text.translatable("tokenlogin.settings.favorites_value",
            onOff(TokenLoginConfig.isFavoritesEnabled()));
    }

    private static Text reorderMessage() {
        return Text.translatable("tokenlogin.settings.reorder_value",
            onOff(TokenLoginConfig.isReorderEnabled()));
    }

    private static Text onOff(boolean value) {
        return Text.translatable(value ? "tokenlogin.common.on" : "tokenlogin.common.off");
    }

    /** The version the loader actually loaded, so the footer matches the jar. */
    private static String version() {
        return FabricLoader.getInstance().getModContainer(TokenLogin.MOD_ID)
            .map(container -> container.getMetadata().getVersion().getFriendlyString())
            .orElse(TokenLogin.VERSION);
    }

    @Override
    public void close() {
        this.client.setScreen(this.parent);
    }

    /** One line of the settings block: a section header, or a control with a note under it. */
    private static final class Row {
        private final boolean header;
        private final Text label;
        private final Text note;
        private final ButtonWidget button;
        /** Top of the row in content coordinates, before scrolling. */
        private int y;
        private int height;
        /** Offset of the note inside the row, or {@code -1} when there is none. */
        private int noteOffset = -1;

        private Row(boolean header, Text label, Text note, ButtonWidget button) {
            this.header = header;
            this.label = label;
            this.note = note;
            this.button = button;
        }

        private static Row header(Text title) {
            return new Row(true, title, null, null);
        }

        private static Row control(Text label, Text note, ButtonWidget button) {
            return new Row(false, label, note, button);
        }
    }
}
