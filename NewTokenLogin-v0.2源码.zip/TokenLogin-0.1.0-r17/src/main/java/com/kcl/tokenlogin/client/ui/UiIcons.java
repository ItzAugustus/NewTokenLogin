package com.kcl.tokenlogin.client.ui;

import net.minecraft.client.gui.DrawContext;

/**
 * The two small icons the account list needs. Minecraft ships no font glyph for
 * a star or a triangle that is safe to rely on, so both are rasterised here from
 * geometry instead of shipping another texture.
 */
final class UiIcons {
    /**
     * A five pointed star, plotted by hand so that every single row is a mirror
     * of itself: the icon is exactly symmetric about its middle column, which a
     * star sampled from an even sized grid could not be.
     */
    private static final String[] STAR = {
        "......###......",
        "......###......",
        "......###......",
        ".....#####.....",
        ".#############.",
        ".#############.",
        "..###########..",
        "...#########...",
        "....#######....",
        "....#######....",
        "...####.####...",
        "...###...###...",
        "...##.....##...",
    };
    private static final int STAR_WIDTH = STAR[0].length();
    private static final int STAR_HEIGHT = STAR.length;
    /** Every filled pixel. */
    private static final boolean[] STAR_BODY = new boolean[STAR_WIDTH * STAR_HEIGHT];
    /** Filled pixels with an empty neighbour: the one pixel outline. */
    private static final boolean[] STAR_EDGE = new boolean[STAR_WIDTH * STAR_HEIGHT];
    /** Filled pixels that are not on the outline. */
    private static final boolean[] STAR_INNER = new boolean[STAR_WIDTH * STAR_HEIGHT];

    static {
        for (int y = 0; y < STAR_HEIGHT; y++) {
            for (int x = 0; x < STAR_WIDTH; x++) {
                STAR_BODY[y * STAR_WIDTH + x] = STAR[y].charAt(x) == '#';
            }
        }
        for (int y = 0; y < STAR_HEIGHT; y++) {
            for (int x = 0; x < STAR_WIDTH; x++) {
                int index = y * STAR_WIDTH + x;
                if (!STAR_BODY[index]) {
                    continue;
                }
                boolean edge = x == 0 || x == STAR_WIDTH - 1 || y == 0 || y == STAR_HEIGHT - 1
                    || !STAR_BODY[index - 1] || !STAR_BODY[index + 1]
                    || !STAR_BODY[index - STAR_WIDTH] || !STAR_BODY[index + STAR_WIDTH];
                STAR_EDGE[index] = edge;
                STAR_INNER[index] = !edge;
            }
        }
    }

    private UiIcons() {
    }

    static int starWidth() {
        return STAR_WIDTH;
    }

    static int starHeight() {
        return STAR_HEIGHT;
    }

    /**
     * Draws the star: a one pixel outline in {@code rimColor} plus, when
     * {@code filled}, a brighter body. An unfilled star keeps only the outline,
     * which is how an account that is not a favourite is drawn.
     */
    static void drawStar(DrawContext context, int x, int y, int rimColor, int fillColor, boolean filled) {
        drawMask(context, x, y, STAR_EDGE, rimColor);
        if (filled) {
            drawMask(context, x, y, STAR_INNER, fillColor);
        }
    }

    /** Draws a mask as one horizontal run per row, so each row is a single fill. */
    private static void drawMask(DrawContext context, int x, int y, boolean[] mask, int color) {
        for (int row = 0; row < STAR_HEIGHT; row++) {
            int runStart = -1;
            for (int col = 0; col <= STAR_WIDTH; col++) {
                boolean filled = col < STAR_WIDTH && mask[row * STAR_WIDTH + col];
                if (filled && runStart < 0) {
                    runStart = col;
                } else if (!filled && runStart >= 0) {
                    context.fill(x + runStart, y + row, x + col, y + row + 1, color);
                    runStart = -1;
                }
            }
        }
    }

    /** A solid 7x4 triangle, centred inside a {@code width} x {@code height} box. */
    static void drawTriangle(DrawContext context, int x, int y, int width, int height,
                             boolean up, int color) {
        int triangleHeight = 4;
        int top = y + (height - triangleHeight) / 2;
        for (int row = 0; row < triangleHeight; row++) {
            int level = up ? row : triangleHeight - 1 - row;
            int span = 1 + level * 2;
            int startX = x + (width - span) / 2;
            context.fill(startX, top + row, startX + span, top + row + 1, color);
        }
    }
}
