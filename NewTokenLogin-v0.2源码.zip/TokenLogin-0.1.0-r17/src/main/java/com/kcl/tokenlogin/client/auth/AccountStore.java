package com.kcl.tokenlogin.client.auth;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.kcl.tokenlogin.TokenLogin;
import com.kcl.tokenlogin.client.config.TokenLoginConfig;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Persistent list of imported accounts. All access happens on the client
 * thread; the file itself is small enough to write synchronously.
 */
public final class AccountStore {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final AccountStore INSTANCE = new AccountStore();

    private final List<Account> accounts = new ArrayList<>();
    private final Path file;
    private boolean loaded;

    private AccountStore() {
        this.file = FabricLoader.getInstance().getConfigDir().resolve("tokenlogin-accounts.json");
    }

    public static AccountStore get() {
        return INSTANCE;
    }

    public synchronized void load() {
        if (loaded) {
            return;
        }
        loaded = true;
        if (!Files.exists(file)) {
            return;
        }
        try {
            JsonObject root = JsonParser.parseString(Files.readString(file, StandardCharsets.UTF_8))
                .getAsJsonObject();
            JsonElement list = root.get("accounts");
            if (list == null || !list.isJsonArray()) {
                return;
            }
            for (JsonElement element : list.getAsJsonArray()) {
                if (!element.isJsonObject()) {
                    continue;
                }
                Account account = GSON.fromJson(element, Account.class);
                if (account != null && account.normalizedId() != null) {
                    // Older builds did not store the import time; start counting
                    // from now instead of showing "imported 55 years ago".
                    if (account.getImportedAt() <= 0L) {
                        account.setImportedAt(System.currentTimeMillis());
                    }
                    accounts.add(account);
                }
            }
        } catch (Exception e) {
            TokenLogin.LOGGER.error("Failed to read accounts from {}", file, e);
        }
    }

    public synchronized void save() {
        try {
            JsonObject root = new JsonObject();
            JsonArray list = new JsonArray();
            for (Account account : accounts) {
                list.add(GSON.toJsonTree(account));
            }
            root.add("accounts", list);
            Path parent = file.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }
            // Write to a temporary file and swap it in, so a crash halfway
            // through a write can never leave a half written account list.
            Path temp = file.resolveSibling(file.getFileName() + ".tmp");
            Files.writeString(temp, GSON.toJson(root), StandardCharsets.UTF_8);
            try {
                Files.move(temp, file, java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                    java.nio.file.StandardCopyOption.ATOMIC_MOVE);
            } catch (java.nio.file.AtomicMoveNotSupportedException e) {
                Files.move(temp, file, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception e) {
            TokenLogin.LOGGER.error("Failed to save accounts to {}", file, e);
        }
    }

    public synchronized List<Account> snapshot() {
        return new ArrayList<>(accounts);
    }

    /**
     * The list in the order the screen shows it: favourites first, and inside
     * each group the manual order the player dragged the accounts into.
     * {@link List#sort} is stable, so swapping an entry to the top of the file
     * is all a favourite needs.
     *
     * <p>When favourites are turned off in the settings the stars are hidden, so
     * the plain file order is shown as well; otherwise a row could float to the
     * top with nothing on screen explaining why.</p>
     */
    public synchronized List<Account> orderedSnapshot() {
        List<Account> ordered = new ArrayList<>(accounts);
        if (!TokenLoginConfig.isFavoritesEnabled()) {
            return ordered;
        }
        ordered.sort(java.util.Comparator.comparing(Account::isFavorite).reversed());
        return ordered;
    }

    /** Position of an account in the file order, or {@code -1}. */
    private int indexOf(String normalizedId) {
        if (normalizedId == null) {
            return -1;
        }
        for (int i = 0; i < accounts.size(); i++) {
            if (normalizedId.equals(accounts.get(i).normalizedId())) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Exchanges the file positions of two accounts, which is how one step up or
     * down in the visible list is drawn. Accounts that are not both in the same
     * favourite group cannot be swapped, because favourites always float.
     */
    public synchronized boolean swap(Account first, Account second) {
        if (first == null || second == null || first == second) {
            return false;
        }
        // Favourites always float, so a row may only change places inside its own
        // group. With favourites turned off there is only one group.
        if (TokenLoginConfig.isFavoritesEnabled() && first.isFavorite() != second.isFavorite()) {
            return false;
        }
        int a = indexOf(first.normalizedId());
        int b = indexOf(second.normalizedId());
        if (a < 0 || b < 0) {
            return false;
        }
        Account moved = accounts.get(a);
        accounts.set(a, accounts.get(b));
        accounts.set(b, moved);
        save();
        return true;
    }

    /** Pins or unpins an account; the change is written to disk right away. */
    public synchronized void setFavorite(Account account, boolean favorite) {
        if (account == null || account.isFavorite() == favorite) {
            return;
        }
        account.setFavorite(favorite);
        save();
    }

    public synchronized Account find(String profileId) {
        if (profileId == null) {
            return null;
        }
        String wanted = profileId.replace("-", "").toLowerCase(java.util.Locale.ROOT);
        for (Account account : accounts) {
            if (wanted.equals(account.normalizedId())) {
                return account;
            }
        }
        return null;
    }

    public synchronized void put(Account account) {
        // Re-importing an existing account must not fling it to the bottom of
        // the list or drop its star, so the slot and the flag are kept.
        int existing = indexOf(account.normalizedId());
        if (existing >= 0) {
            Account previous = accounts.get(existing);
            account.setFavorite(previous.isFavorite());
            accounts.set(existing, account);
        } else {
            accounts.add(account);
        }
        save();
    }

    public synchronized void remove(Account account) {
        accounts.remove(account);
        save();
    }

    public synchronized int size() {
        return accounts.size();
    }
}
